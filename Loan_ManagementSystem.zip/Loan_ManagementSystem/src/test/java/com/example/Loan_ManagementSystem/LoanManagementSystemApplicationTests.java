package com.example.Loan_ManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
